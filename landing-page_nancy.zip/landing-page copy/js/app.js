/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/


const sec = [...document.querySelectorAll('section')];//get sections in array
const nav = document.getElementById('navbar__list');//get the nav div to append the nav on it





/**
 * End Global Variables
 * Start Helper Functions
 * 
*/
//creat nav function
//looping throw secections to get it attributes "data nav"for the name, and"id" for link
function createNavBar(){
  for(section of sec){
    secName = section.getAttribute('data-nav');
    secLink = section.getAttribute('id');
    

    //creat li inside ul nav, the add anchor html
    navItem = document.createElement('li');
    navItem.innerHTML="<a class='menu__link' href=''}>"+secName+"</a>";//can't pass the var secName!
  
  

  //append li inside the nav
    nav.appendChild(navItem);
  }
}
createNavBar();//call nav function

/*window listener for active section
active section'top <200 & >-300*/
window.addEventListener("scroll", function(){
  for(section of sec){
  if(section.getBoundingClientRect().top<200 && section.getBoundingClientRect().top>-300){
    section.classList.add("your-active-class");
    
  }else{
    section.classList.remove("your-active-class");
    
  }
}
  
})



/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav


// Add class 'active' to section when near top of viewport


// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click

// Set sections as active


